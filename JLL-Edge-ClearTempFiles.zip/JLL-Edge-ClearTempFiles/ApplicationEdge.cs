﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JLL_Edge_ClearTempFiles
{
    class ApplicationEdge
    {
        public static string UserProfile
        {
            get; set;
        }

        public static string UserName
        {
            get; set;
        }

        static DateTime Start
        {
            get; set;
        }
        static DateTime End
        {
            get; set;
        }

        public static string UserProfile
        {
            get; set;
        }
        public static string UserName = Environment.UserName;
        public static string EdgePath
        {
            get; set;
        }
        private static string GetEdgePath()
        {
            string getEdgePath = @"C:\Windows\SystemApps\Microsoft.MicrosoftEdge_8wekyb3d8bbwe\MicrosoftEdge.exe";
            if (File.Exists(getEdgePath))
            {
                EdgePath = getEdgePath;
                return EdgePath;
            }

            return "NOT FOUND";
        }


        public static void HeaderInfo()

        {

            Console.Title = typeof(Program).Namespace;

            Console.BackgroundColor = ConsoleColor.Black;

            Console.ForegroundColor = ConsoleColor.DarkGreen;





            var process = Process.GetCurrentProcess(); // Or whatever method you are using

            string thisAppfullPath = process.MainModule.FileName;

            Console.WriteLine($"{ ("String28")} { typeof(Program).Namespace}");

            Console.WriteLine($"{ ("String27")}: { new System.IO.FileInfo(thisAppfullPath).Length / 1024} KB");

            Start = DateTime.Now;

            Console.WriteLine($"{ ("String29")} { DateTime.Now.ToLongTimeString()}");

            Console.WriteLine(Environment.NewLine);

            Console.WriteLine(Environment.NewLine);
        }
        public static void FootInfo()

        {

            Console.WriteLine(Environment.NewLine);

            Console.WriteLine(Environment.NewLine);

            End = DateTime.Now;

            Console.WriteLine($"{ ("String30")} {DateTime.Now.ToLongTimeString()}");

            Console.WriteLine($"{ ("String31")} {End.Subtract(Start).TotalSeconds} seconds");

            Console.ReadKey();



        }



        public static void GetUserProfileDirectory()

        {

            string cDrive = Path.GetPathRoot(Environment.SystemDirectory);

            ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT UserName FROM Win32_ComputerSystem");

            ManagementObjectCollection collection = searcher.Get();

            UserName = Path.GetFileName(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));

            UserProfile = System.Environment.GetFolderPath(System.Environment.SpecialFolder.UserProfile);

        }
        public static string GetcurrentUser()
        {
            string query = "Select * from Win32_Process";
            ManagementObjectSearcher searcher = new ManagementObjectSearcher(query);
            ManagementObjectCollection Processes = searcher.Get();

            foreach (System.Management.ManagementObject Process in Processes)
            {
                if (Process["ExecutablePath"] != null && System.IO.Path.GetFileName(Process["ExecutablePath"].ToString()).ToLower() == "explorer.exe")
                {
                    string[] OwnerInfo = new string[2];
                    Process.InvokeMethod("GetOwner", (object[])OwnerInfo);
                    return OwnerInfo[0];

                }

            }
            return UserName;
        }
    }

}
