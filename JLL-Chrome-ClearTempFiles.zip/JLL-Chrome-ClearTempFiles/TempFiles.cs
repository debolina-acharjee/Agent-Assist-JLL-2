﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JLL_Chrome_ClearTempFiles
{
    class TempFiles
    {
        public static void DeleteAppDataTemp()
        {
            string appDataTempPath = Path.GetTempPath();
            Console.WriteLine($"Temporary folder in %appdata%/temp{SizeConversion.GetBytesReadable(Application.GetDirectorySize(appDataTempPath)).PadLeft(25, '.')}");
            ulong AppDataTempSizeDeleted = Application.EmptyFolder(appDataTempPath);
            Console.WriteLine($@"Cleaned {SizeConversion.GetBytesReadable(AppDataTempSizeDeleted)}");
        }
    }

}
 