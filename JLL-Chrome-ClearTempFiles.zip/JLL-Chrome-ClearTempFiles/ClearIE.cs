﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JLL_Chrome_ClearTempFiles
{
    class ClearIE
    {
        public static void ExecuteClearIECache(string clearType)

        {

            try

            {
                switch (clearType)
                {
                    case "TempFiles":

                        //Temporary Internet Files

                        var temp = System.Diagnostics.Process.Start("rundll32.exe", "InetCpl.cpl,ClearMyTracksByProcess 8200");

                        while (!temp.HasExited)

                        {



                        }

                        break;
                    case "Cookies":

                        //Cookies

                        var cook = System.Diagnostics.Process.Start("rundll32.exe", "InetCpl.cpl,ClearMyTracksByProcess 8194");

                        while (!cook.HasExited)

                        {



                        }

                        break;
                    default:

                        Console.WriteLine("Tempfiles will be deleted ");
                        Console.ReadLine();

                        break;

                }

            }

            catch (Exception ex)

            {

                Console.Write(ex.StackTrace);

                Console.ReadLine();

            }

        }
    }
}

