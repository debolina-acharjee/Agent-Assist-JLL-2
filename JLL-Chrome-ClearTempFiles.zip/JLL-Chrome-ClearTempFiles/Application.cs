﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using System.Text;
using System.Threading.Tasks;

namespace JLL_Chrome_ClearTempFiles
{
    class Application
    {
        public static string UserProfile

        {

            get; set;

        }



        public static string UserName

        {

            get; set;

        }



        static DateTime Start

        {

            get; set;

        }

        static DateTime End

        {

            get; set;

        }
         public static void HeaderInfo()

        {

            Console.BackgroundColor = ConsoleColor.Black;

            Console.ForegroundColor = ConsoleColor.DarkGreen;

            var process = Process.GetCurrentProcess(); // Or whatever method you are using

            string thisAppfullPath = process.MainModule.FileName;

            Console.WriteLine($"Scriptlet Name: {typeof(Program).Namespace}");

            Console.WriteLine($"Size: {new FileInfo(thisAppfullPath).Length / 1024} KB");

            Start = DateTime.Now;

            Console.WriteLine($"Start Time: {DateTime.Now.ToLongTimeString()}");

            Console.WriteLine(Environment.NewLine);

            Console.WriteLine(Environment.NewLine);



            Console.ForegroundColor = ConsoleColor.DarkGreen;

        }


        public static void FootInfo()

        {

            Console.WriteLine(Environment.NewLine);

            Console.WriteLine(Environment.NewLine);

            End = DateTime.Now;

            Console.WriteLine($"End Time: {DateTime.Now.ToLongTimeString()}");

            Console.WriteLine($"Execution Time: {End.Subtract(Start).TotalSeconds} seconds");

            Console.ReadKey();
        }

        public static string GetIEPath

        {

            get; set;

        }
        public static void GetUserProfileDirectory()

        {



            string cDrive = Path.GetPathRoot(Environment.SystemDirectory);

            ManagementObjectSearcher searcher = new ManagementObjectSearcher("SELECT UserName FROM Win32_ComputerSystem");

            ManagementObjectCollection collection = searcher.Get();



            UserName = Path.GetFileName(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));

            UserProfile = System.Environment.GetFolderPath(System.Environment.SpecialFolder.UserProfile);

            //UserName = Path.GetFileName(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));

            //UserProfile = System.Environment.GetFolderPath(System.Environment.SpecialFolder.UserProfile);

        }


        public static void CheckApplicationExists()

        {

            if (GetIEVersion() == "NOT FOUND")

            {

                Console.WriteLine("NOT FOUND");

                //Exit code 1 when application version is not found

                Environment.Exit(1);

            }

        }

        public static string GetIEVersion()

        {

            string getIE64BitPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ProgramFiles) + @"\internet explorer\iexplore.exe";

            string getIE32BitPath = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ProgramFilesX86) + @"\Internet Explorer\iexplore.exe";



            if (File.Exists(getIE64BitPath))

            {

                GetIEPath = getIE64BitPath;

                return "64";

            }



            else if (File.Exists(getIE32BitPath))

            {

                GetIEPath = getIE32BitPath;

                return "32";

            }

            return "NOT FOUND";

        }



        public static void LaunchIE()

        {

            Process.Start(GetIEPath);


        }
        public static ulong GetDirectorySize(string folderPath)
        {
            ulong length = (ulong)Directory.GetFiles(folderPath, "*", SearchOption.AllDirectories).Sum(t => (new FileInfo(t).Length));
            return length;
        }
        public static ulong EmptyFolder(string directoryName)
        {
            ulong accum = 0;
            DirectoryInfo directory = new DirectoryInfo(directoryName);
            foreach (FileInfo file in directory.GetFiles())
            {
                try
                {
                    accum += (ulong)file.Length;
                    file.Delete();
                }
                catch
                {
                    accum -= (ulong)file.Length;
                }
            }
            foreach (DirectoryInfo subDirectory in directory.GetDirectories())
            {
                ulong subDirectorySize = GetDirectorySize(subDirectory.FullName);
                try
                {
                    accum += subDirectorySize;
                    EmptyFolder(subDirectory.FullName);
                    subDirectory.Delete(true);
                }
                catch
                {
                    accum -= subDirectorySize;
                }
            }
            return accum;
        }

    }


}


//}


