﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace JLL_Chrome_ClearTempFiles
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Application.HeaderInfo();



                #region PreliminaryChecks

                Console.WriteLine("Checking Internet Explorer");

                Application.CheckApplicationExists();

                Application.GetUserProfileDirectory();

                #endregion



                #region Disclaimer

                var discInput = UserPrompt.Disclaimer("The program will attempt to fix Internet Explorer issues.\nTroubleshooting requires that Internet Explorer is closed.\nDo you want to proceed ?");

                if (discInput.ToString() == "No")

                {

                    UserPrompt.Disclaimer("Permission denied, program will now exit!");

                    return;

                }

                Console.WriteLine("Closing Internet Explorer if its still open.");

                CloseProcess.KillProcessByNameAndUserName("iexplore", Application.UserName);

                #endregion
                #region LaunchingIE
                Application.CheckApplicationExists();
                Application.LaunchIE();

                #endregion

                #region Clear Windows Temp Files

                //TempFile.DeleteAppDataTemp();
               // Directory.DirectoryDelete(@"C: \AppData\Local\Temp", "*", System.IO.SearchOption.AllDirectories);
                TempFiles.DeleteAppDataTemp();
                Console.WriteLine("Deleting the file");

                #endregion

                #region Clear IE Cache
                Console.WriteLine("Clearing the TempFiles");
                ClearIE.ExecuteClearIECache("TempFiles");
                #endregion
            }

            catch (Exception ex)

            {
                Console.WriteLine("Error Occurred" + ex);
            }

            finally

            {
                Application.FootInfo();

                DeleteOnConsoleClose.DeleteFixlet();
            }
        }
    }
}


