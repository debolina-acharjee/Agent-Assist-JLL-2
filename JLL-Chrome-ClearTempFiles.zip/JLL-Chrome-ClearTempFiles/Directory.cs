﻿//using System;
//using System.Collections.Generic;
//using System.IO;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace JLL_Chrome_ClearTempFiles
//{
//    class Directory
//    {
//            public static void DirectoryDelete(string directoryName, string Pattern, SearchOption so, string matchRegStr = null)

//            {

//                if (!System.IO.Directory.Exists(directoryName))

//                {

//                    Console.WriteLine("Specified directory not found");

//                    return;

//                }

//                string[] dirs = Array.Empty<string>();

//                if (matchRegStr != null)

//                {

//                    //Regex reg = new Regex(matchRegStr);

//                    try

//                    {

//                        dirs = System.IO.Directory.GetDirectories(directoryName)

//                        //.Where(x => reg.IsMatch(x))

//                        .ToArray();

//                    }

//                    catch (Exception excep)

//                    {

//                        System.Diagnostics.Debug.WriteLine(excep);

//                    }



//                }

//                else

//                {

//                    try

//                    {

//                        dirs = System.IO.Directory.GetDirectories(directoryName, Pattern, so);

//                    }

//                    catch (Exception excep)

//                    {

//                        System.Diagnostics.Debug.WriteLine(excep);

//                    }

//                }



//                foreach (var dir in dirs)

//                {

//                    String[] getFileDownload1 = Array.Empty<string>();



//                    try

//                    {

//                        getFileDownload1 = System.IO.Directory.GetFiles($@"{dir}", "*", SearchOption.AllDirectories);

//                    }

//                    catch (Exception excep)

//                    {



//                        System.Diagnostics.Debug.WriteLine(excep);

//                    }

//                    foreach (var file in getFileDownload1)

//                    {

//                        try

//                        {

//                            File.Delete(file);

//                        }

//                        catch (Exception excep)

//                        {

//                            System.Diagnostics.Debug.WriteLine(excep);

//                        }

//                    }

//                    try

//                    {

//                        System.IO.Directory.Delete(dir, true);

//                    }

//                    catch (Exception ex)

//                    {

//                        System.Diagnostics.Debug.WriteLine(ex);

//                    }

//                }

//                String[] getFileDownload = Array.Empty<string>();

//                try

//                {

//                    getFileDownload = System.IO.Directory.GetFiles($@"{directoryName}", "*", SearchOption.AllDirectories);

//                }

//                catch (Exception excep)

//                {

//                    System.Diagnostics.Debug.WriteLine(excep);

//                }

//                foreach (var file in getFileDownload)

//                {

//                    try

//                    {

//                        File.Delete(file);

//                    }

//                    catch (Exception excep)

//                    {

//                        System.Diagnostics.Debug.WriteLine(excep);

//                    }

//                }

//            }



//            /// <summary>

//            /// It deletes the file from specified folder path.

//            /// </summary>

//            /// <param name="targetFolder">

//            /// Specify the path of the folder where files needs to deleted

//            /// </param>

//            /// <param name="fileType">

//            /// File type can specified or by default all the files will be deleted from the given path

//            /// </param>



//            public static void ClearFiles(string targetFolder, string fileType = "*")

//            {

//                String[] logFiles = Array.Empty<string>();



//                try

//                {

//                    logFiles = System.IO.Directory.GetFiles(targetFolder, "*" + fileType, SearchOption.AllDirectories);

//                }

//                catch (Exception excep)

//                {



//                    Console.WriteLine(excep);

//                }

//                foreach (var file in logFiles)

//                {

//                    try

//                    {

//                        File.Delete(file);

//                    }

//                    catch (Exception excep)

//                    {

//                        Console.Write(excep.StackTrace);

//                    }

//                }

//            }





//        }

//    }


