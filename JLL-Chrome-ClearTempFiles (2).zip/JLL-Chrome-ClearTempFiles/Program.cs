﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;

namespace JLL_Chrome_ClearTempFiles
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                ApplicationChrome.HeaderInfo();



                #region PreliminaryChecks

                Console.WriteLine("Checking does Chrome exist");

                ApplicationChrome.CheckApplicationExists();

                ApplicationChrome.GetUserProfileDirectory();

                #endregion



                #region Disclaimer

                var discInput = UserPrompt.Disclaimer("The program will attempt to fix Chrome issues.\nTroubleshooting requires that Chrome is closed.\nDo you want to proceed ?");

                if (discInput.ToString() == "No")

                {

                    UserPrompt.Disclaimer("Permission denied, program will now exit!");

                    return;

                }

                Console.WriteLine("Closing Internet Explorer if its still open.");

                CloseProcess.KillProcessByNameAndUserName("iexplore", ApplicationChrome.UserName);

                #endregion
                #region LaunchingChrome
                ApplicationChrome.CheckApplicationExists();
                ApplicationChrome.LaunchApplication();

                #endregion

                #region Clear Windows Temp Files

                //TempFile.DeleteAppDataTemp();
               // Directory.DirectoryDelete(@"C: \AppData\Local\Temp", "*", System.IO.SearchOption.AllDirectories);
                TempFiles.DeleteAppDataTemp();
                Console.WriteLine("Deleting the file");

                #endregion

                #region Clear Chrome Cache
                Console.WriteLine("Clearing the TempFiles");
                #endregion
            }

            catch (Exception ex)

            {
                Console.WriteLine("Error Occurred" + ex);
            }

            finally

            {
                ApplicationChrome.FootInfo();

                DeleteOnConsoleClose.DeleteFixlet();
            }
        }
    }
}


